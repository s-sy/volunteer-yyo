// pages/user/user-team/index.js
 const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    imgData:[],
    name:"",
    address:"",
    legal:"",
    card:"",
    phone:"",
    modalName:"",
  },
  changeTab(e){
    let index=e.currentTarget.dataset.index;
    this.setData({
      index:index
    })
  },
  todetail(){
    wx.navigateTo({
      url: '../user-team-detail/index',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  inputName(e){ //公司名称
    console.log(e);
    
    this.setData({
      name:e.detail.value
    })
  },
  inputAddress(e){ //公司地址
    this.setData({
      address:e.detail.value
    })
  },
  inputLegal(e){  //法人姓名
    this.setData({
      legal:e.detail.value
    })
  },
  inputCard(e){  //身份证号码
    this.setData({
      card:e.detail.value
    })
  },
  inputPhone(e){ //联系电话
    this.setData({
      phone:e.detail.value
    })
  },
  onLoadImg(){   // 营业执照
    let that=this;
    console.log("122");
    wx.chooseImage({
      count: 9-that.data.imgData,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success (res) {
          // tempFilePath可以作为img标签的src属性显示图片
         console.log(res)
         let tempFilePaths = res.tempFilePaths
         let imgList=that.data.imgData
         console.log(getApp().globalData.thirdSession)
        //  const uploadTask =wx.uploadFile({
        //     filePath: tempFilePaths[0],
        //     name: 'file',
        //     url: 'url',
        //     formData: {
        //       'dir':'material',
        //       'fileType':'image',
        //       },
        //     header:{
        //       'app-id': wx.getAccountInfoSync().miniProgram.appId,
        // 'third-session': getApp().globalData.thirdSession
        //     },  
        //     success(res){
        //         console.log(res);
        //       },
        //   })
        //   uploadTask.onProgressUpdate((res) => {
        //     console.log('上传进度', res.progress)
        //     console.log('已经上传的数据长度', res.totalBytesSent)
        //     console.log('预期需要上传的数据总长度', res.totalBytesExpectedToSend)
        //   })
        // for(let i =0;i<tempFilePaths.length;i++){
         // imgList.push(tempFilePaths[i])
        that.qiniuupload(0,tempFilePaths,tempFilePaths.length)
        // }
        // console.log(tempFilePaths);
        //  that.setData({
        //   imgData: imgList
        //  })

        // console.log(that.data.imgData)
         }
    })

  },
  qiniuupload(i,data,length){
    let that=this;
    console.log("qiniuupload")
    console.log(wx.getAccountInfoSync().miniProgram.appId)
    console.log(app.api.uploadImage)
    console.log(getApp().globalData.thirdSession)
    wx.uploadFile({
      filePath: data[i],
      // files:data,
      name: 'file',
      url: app.api.uploadImage,
      formData: {
        'dir':'material',
        'fileType':'image',
        },
      header: {
        "content-type":"multipart/form-data",
        'app-id': wx.getAccountInfoSync().miniProgram.appId,
        'third-session': getApp().globalData.thirdSession != null ? getApp().globalData.thirdSession : ''
      },
      
      success: (result)  =>{
        console.log(result)
        that.data.imgData.push(JSON.parse(result.data).link)
        i=i+1
        if(i<length){
          that.qiniuupload(i,data,length)
        }
      },
      fail: (res) =>{
        console.log(res)
      },
      complete: (res) => {
        console.log("_________")
        console.log(res)
      },
    })
    // wx.uploadFile({
    //   url:app.api.uploadImage,
    //   files:data,
    //   filePath: data[i],
    //   name: 'file',
    //   fileType:'image',
    //   header:{
    //     'app-id': wx.getAccountInfoSync().miniProgram.appId,
    //     'third-session': getApp().globalData.thirdSession != null ? getApp().globalData.thirdSession : ''
    //   },
    //   formData:{
    //     dir:'material',
    //     fileType:'image',
    //     },
    //   success:(res)=>{
    //     console.log(res)
    //     that.data.imgData.push(JSON.parse(res.data).link)
    //     i=i+1
    //     if(i<length){
    //       that.qiniuupload(i,data,length)
    //     }
    //   }
    // })
  },
  deleteImg(e){
     console.log("1")
     let index=e.currentTarget.dataset.index;
     console.log(index);
    
     this.setData({
      imgData:this.data.imgData.splice(index,1)
     })
  },
  onCommit(){
   
    if(this.data.imgData.length==0||this.data.name==""||this.data.address==""||this.data.legal=="" ||this.data.card==""||this.data.phone==""){
      this.showModal()
      return;
    }
    let data={
      id:"",
      tenantId:"",
      classification:"", //分类1、单位/企业 2、民间团体不能为空"
      createTime:"", //创建时间
      updateTime:"", //最后更新时间
      createId:"", // 创建者ID
      name:"",//名称
      address:"",//地址
      principal:"",//联系人
      phone:"", //手机号码
      businessLicense:"",//营业执照
      teamNumber:"",//组织总人数
      introduction:"",//介绍
      picUrls:[],//组织展示图片组
    };
    app.api.createTeam(data).then((res)=>{
      console.log(res);
    })

  },
  showModal() {
    this.setData({
      modalName:'Modal'
    });
  },
  hideModal() {
 
    this.setData({
      modalName:"",
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})